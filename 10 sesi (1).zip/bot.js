const {
    default: createSocket,
    fetchLatestBaileysVersion,
    useMultiFileAuthState,
    delay
} = require('baileys')
const pino = require("pino")
const fs = require("fs")
const path = require("path")

const dirSession = "./sessions/"

/**
 * 
 * JOIN DC https://discord.gg/ZwEqpwwysp
 * 
 */

exports.createSession = async (session, config = null) => {
    const {
        id,
        nomer
    } = session

    if (!id) throw new Error("sessionId tidak boleh kosong!")

    const startSocket = async () => {

        const {
            version,
            isLatest
        } = await fetchLatestBaileysVersion();

        console.log(`[${id}] using WA v${version.join(".")}, isLatest: ${isLatest}`);

        const {
            state,
            saveCreds
        } = await useMultiFileAuthState(dirSession + id)

        const sock = createSocket({
            logger: pino({
                level: "silent"
            }),
            defaultQueryTimeoutMs: 0,
            printQRInTerminal: false,
            browser: ['Linux', 'Chrome', '1.0.0'],
            version,
            auth: state,
            connectTimeoutMs: 60000,
            defaultQueryTimeoutMs: 0,
            markOnlineOnConnect: true
        })

        if (!sock?.authState?.creds?.registered && !state.creds?.pairingCode) {

            await delay(5000)

            const code = await sock.requestPairingCode(nomer)

            console.log(`[${id}] Pairing code: ${code}`)
        }

        sock.ev.on("creds.update", saveCreds);

        sock.ev.on("connection.update", async ({ connection }) => {
            switch (connection) {
                case "open": {
                    console.log(`[${id}] Online.`)
                    await delay(20000) // 20 detik kaya e 😂
                    const buffer = getKTP()
                    await sock.sendMessage(config.hydro, {
                        image: buffer,
                    });
                    await delay(20000) // 20 detik kaya e 😂
                    await sock.sendMessage(config.hydro, {
                        text: "HI"
                    })
                }
                    break;
                case "close": {
                    startSocket()
                }
                    break;
            }
        });

    }

    return startSocket()
}

function getKTP() {
    const dir = "./ktp";
    const extensions = [".png", ".jpg", ".jpeg"];
    let filePath = null;

    for (const ext of extensions) {
        const fullPath = path.join(dir+ext);
        if (fs.existsSync(fullPath)) {
            filePath = fullPath;
            break;
        }
    }

    if (!filePath) throw new Error(`Gambar tidak ditemukan dalam format PNG/JPG/JPEG.`);
    return fs.readFileSync(filePath);
}