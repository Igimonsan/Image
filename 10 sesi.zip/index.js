const { delay } = require("baileys");
const socket = require("./bot.js");
const config = require("./config.json");

/**
 * 
 * JOIN DC https://discord.gg/ZwEqpwwysp
 * 
 */

const handleErrors = (name, error) => console.error(name, error);
["unhandledRejection", "uncaughtException", "unhandledPromiseRejection"]
  .forEach(event => process.on(event, handleErrors));

async function start() {
  if (!config?.sessions || config?.sessions?.length === 0) throw new Error("Sessions' empty!");

  for (const session of config.sessions) {
    await socket.createSession(session, config);
    await delay(60 * 1000) // 1 menit ya 
  }
}

start();